import type { CSSProperties } from "react";
import type { EventColor } from "@/lib/types";

export const EVENT_COLORS: EventColor[] = [
  "blue",
  "cyan",
  "green",
  "orange",
  "pink",
  "purple",
  "teal",
  "slate",
];

/**
 * Display name of every EventColor. Typed as a full Record so a colour added to the EventColor type
 * cannot ship without a label (and its --event-<name>-bg/fg tokens in globals.css).
 */
export const EVENT_COLOR_LABELS: Record<EventColor, string> = {
  blue: "Biru",
  cyan: "Cyan",
  green: "Hijau",
  orange: "Oranye",
  pink: "Pink",
  purple: "Ungu",
  teal: "Teal",
  slate: "Abu-abu",
};

/** Inline style for an event surface using paired bg/fg tokens. */
export function eventStyle(color: EventColor): CSSProperties {
  return {
    background: `var(--event-${color}-bg)`,
    color: `var(--event-${color}-fg)`,
  };
}