"use client";

import { useMemo } from "react";
import { cn } from "@/lib/utils";
import { useAppStore } from "@/stores/app-store";
import { useCalendarStore } from "@/stores/calendar-store";
import { openOverlay } from "@/stores/overlay-store";
import { eventStyle } from "./event-colors";
import { useStudyStore } from "@/stores/study-store";
import { useToday } from "@/hooks/use-today";
import { studyTasksByDay } from "@/features/scheduling/calendar-tasks";

type Chip = { kind: "event" | "holiday" | "task"; done?: boolean; id: string; title: string; style: React.CSSProperties };

const CHIP_HEIGHT = 28;
const CHIP_GAP = 4;
const ROW_PADDING = 5.5;

/** The all-day lane above the time grid: holidays first, then all-day events. */
export function AllDayRow({ days }: { days: string[] }) {
  const events = useAppStore((s) => s.events);
  const holidays = useAppStore((s) => s.holidays);
  const openPopover = useCalendarStore((s) => s.openPopover);
  const studyTasks = useStudyStore((s) => s.tasks);
  const today = useToday();

  const chipsByDay = useMemo(
    () =>
      days.map((day): Chip[] => [
        ...(studyTasksByDay(studyTasks, today).get(day) ?? []).map((t) => ({ kind: "task" as const, done: t.done, id: `task:${t.id}`, title: `${t.done ? "✓ " : ""}${t.label} · ${t.title}`, style: eventStyle(t.done ? "slate" : t.overdue ? "orange" : "teal") })),
        ...holidays
          .filter((h) => h.date === day)
          .map((h) => ({ kind: "holiday" as const, id: h.id, title: "National holiday", style: eventStyle("purple") })),
        ...events
          .filter((e) => e.allDay && e.date === day)
          .map((e) => ({ kind: "event" as const, id: e.id, title: e.title, style: eventStyle(e.color) })),
      ]),
    [days, events, holidays, studyTasks, today],
  );

  const most = Math.max(1, ...chipsByDay.map((c) => c.length));
  const height = ROW_PADDING * 2 + most * CHIP_HEIGHT + (most - 1) * CHIP_GAP + 1;

  return (
    <div className="flex w-full shrink-0 items-stretch overflow-hidden border-b border-hairline" style={{ height }}>
      <div className="sticky left-0 z-10 flex w-(--axis) shrink-0 items-center justify-end bg-[var(--glass-sticky)] pr-3 max-md:pr-1.5">
        {most > 1 && <span className="t-12 text-placeholder max-md:text-[10px]">All day</span>}
      </div>
      {days.map((day, i) => (
        <div
          key={day}
          role="group"
          aria-label="All-day events"
          onClick={(e) => {
            if (e.target === e.currentTarget) openOverlay({ kind: "event", date: day, allDay: true });
          }}
          className="flex min-w-0 flex-1 cursor-default flex-col justify-center gap-1 overflow-hidden border-l border-hairline px-1 max-md:px-0.5"
        >
          {chipsByDay[i].map((chip) => (
            <button
              key={chip.id}
              type="button"
              onClick={(e) => (chip.kind === "task" ? (chip.done ? undefined : openOverlay({ kind: "study-checkin", taskId: chip.id.slice(5) })) : openPopover(chip.kind, chip.id, e.currentTarget))}
              className={cn(
                "press flex h-7 w-full shrink-0 items-center overflow-hidden rounded-lg px-2 text-left outline-none max-md:rounded-md max-md:px-1",
                "hover-fine:brightness-[0.97] focus-visible:ring-2 focus-visible:ring-brand/60 dark:hover-fine:brightness-110",
              )}
              style={chip.style}
            >
              <span className="t-14 salt min-w-0 flex-1 truncate max-md:text-[11px] max-md:tracking-normal">{chip.title}</span>
            </button>
          ))}
        </div>
      ))}
    </div>
  );
}
