"use client";

import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { completionBounds, validateCompletionDate } from "@/features/scheduling/scheduler";
import { useToday } from "@/hooks/use-today";
import { formatLong } from "@/lib/dates";
import { completionDateKey, formatRecordedAt } from "@/lib/study-dates";
import { useStudyStore } from "@/stores/study-store";

/**
 * Edits the study day of a topic that is already completed. Only the day changes: the reflection and the
 * real record time (`recordedAt`) stay as they were, and later topics are re-scheduled from the new day.
 */
export function CompletionDateDialog({ open, taskId, onClose }: { open: boolean; taskId?: string; onClose: () => void }) {
  const tasks = useStudyStore((state) => state.tasks);
  const setCompletionDate = useStudyStore((state) => state.setCompletionDate);
  const today = useToday();
  const task = tasks.find((item) => item.id === taskId);
  const current = task?.completedAt ? completionDateKey(task.completedAt) : "";
  const [picked, setPicked] = useState("");
  const day = picked || current;
  const bounds = taskId ? completionBounds(tasks, taskId, today) : undefined;
  const error = taskId && day ? validateCompletionDate(tasks, taskId, day, today) : null;
  const close = () => { setPicked(""); onClose(); };

  return (
    <Dialog open={open} onOpenChange={(value) => !value && close()}>
      <DialogContent className="gap-4 p-5 sm:max-w-[420px]">
        <DialogHeader className="gap-1.5">
          <DialogTitle>Ubah tanggal selesai</DialogTitle>
          <DialogDescription>{task?.title}</DialogDescription>
        </DialogHeader>
        <div className="grid gap-3 text-sm text-fg">
          <div>
            <label htmlFor="completion-date" className="mb-2 block font-medium">Tanggal belajar</label>
            <Input id="completion-date" type="date" value={day} min={bounds?.min} max={bounds?.max} aria-invalid={Boolean(error)} aria-describedby="completion-date-hint" onChange={(event) => setPicked(event.target.value)} />
            <p id="completion-date-hint" className={`mt-1.5 text-xs ${error ? "text-danger" : "text-fg-2"}`}>
              {error ?? (day ? formatLong(day) : "Pilih tanggal.")}
            </p>
          </div>
          {task?.recordedAt && <p className="text-xs text-fg-2">Pertama kali dicatat: {formatRecordedAt(task.recordedAt)}. Waktu pencatatan tidak berubah.</p>}
        </div>
        <DialogFooter>
          <Button type="button" variant="ghost" onClick={close}>Batal</Button>
          <Button type="button" variant="brand" disabled={!taskId || !day || Boolean(error) || day === current} onClick={() => { if (taskId && setCompletionDate(taskId, day)) close(); }}>Simpan tanggal</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
