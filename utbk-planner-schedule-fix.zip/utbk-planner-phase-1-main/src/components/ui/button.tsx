import * as React from "react";
import { cva, type VariantProps } from "class-variance-authority";
import { cn } from "cn";
import { Slot } from "radix-ui";

const buttonVariants = cva(
  "group/button inline-flex shrink-0 items-center justify-center rounded-lg border border-transparent bg-clip-padding t-14 salt font-medium whitespace-nowrap outline-none select-none transition-[background-color,border-color,color,box-shadow,opacity,transform] duration-150 ease-(--ease-out) active:scale-[0.97] focus-visible:ring-3 focus-visible:ring-ring/40 disabled:pointer-events-none disabled:opacity-50 aria-invalid:border-destructive [&_svg]:pointer-events-none [&_svg]:shrink-0 [&_svg:not([class*='size-'])]:size-3.5",
  {
    variants: {
      variant: {
        /** White control with the hairline border used across the design */
        control:
          "border-control bg-surface text-fg hover-fine:bg-hover aria-expanded:bg-hover data-[state=open]:bg-hover",
        /** Emerald-to-lime primary action */
        brand:
          "accent-surface hover-fine:brightness-[1.08] hover-fine:shadow-[0_8px_24px_rgba(199,243,107,0.18)]",
        default: "bg-primary text-primary-foreground hover-fine:bg-brand-strong",
        outline:
          "border-control bg-surface text-fg hover-fine:bg-hover aria-expanded:bg-hover",
        secondary: "bg-app text-fg hover-fine:bg-hover",
        ghost: "text-fg-2 hover-fine:bg-hover hover-fine:text-fg aria-expanded:bg-hover aria-expanded:text-fg",
        destructive:
          "bg-[var(--status-danger-tint)] text-danger hover-fine:bg-[rgba(239,71,71,0.14)] focus-visible:ring-destructive/30",
        link: "text-brand underline underline-offset-2 hover-fine:text-brand-strong",
      },
      size: {
        default: "h-[30px] gap-1.5 px-[11px]",
        sm: "h-7 gap-1.5 px-[6px]",
        lg: "h-9 gap-2 px-3.5",
        icon: "size-[30px]",
        "icon-sm": "size-7",
        "icon-lg": "size-8",
      },
    },
    defaultVariants: {
      variant: "control",
      size: "default",
    },
  }
);

function Button({
  className,
  variant = "control",
  size = "default",
  asChild = false,
  ...props
}: React.ComponentProps<"button"> &
  VariantProps<typeof buttonVariants> & {
    asChild?: boolean;
  }) {
  const Comp = asChild ? Slot.Root : "button";

  return (
    <Comp
      data-slot="button"
      data-variant={variant}
      data-size={size}
      className={cn(buttonVariants({ variant, size, className }))}
      {...props}
    />
  );
}

export { Button, buttonVariants };
