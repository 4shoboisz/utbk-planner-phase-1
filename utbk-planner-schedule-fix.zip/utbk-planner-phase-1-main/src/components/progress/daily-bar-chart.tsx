import { cn } from "@/lib/utils";
import { dayLabel, type DayValue } from "@/features/progress/progress-utils";

type Props = {
  /** One entry per day, oldest first. All zeros is fine (empty state). */
  data: DayValue[];
  today: string;
  /** "75 menit" / "3 materi": used in labels and the screen-reader summary. */
  formatValue: (value: number) => string;
  /** Short label printed above a bar, e.g. "1h 15m". */
  formatBar: (value: number) => string;
  emptyMessage: string;
  className?: string;
};

/** Plain CSS/React bar chart: no chart dependency, theme tokens only, safe when every value is 0. */
export function DailyBarChart({ data, today, formatValue, formatBar, emptyMessage, className }: Props) {
  const max = Math.max(0, ...data.map((d) => d.value));
  const empty = max === 0;
  const summary = data.map((d) => `${dayLabel(d.date)} ${formatValue(d.value)}`).join(", ");

  return (
    <div className={className}>
      <div role="img" aria-label={`Grafik 7 hari terakhir: ${summary}`} className="grid h-40 grid-cols-7 items-end gap-2 sm:gap-3">
        {data.map((d) => {
          const isToday = d.date === today;
          // Nonzero values always get a visible bar; zero gets a thin baseline.
          const height = d.value > 0 ? Math.max(8, Math.round((d.value / max) * 100)) : 0;
          return (
            <div key={d.date} className="flex h-full min-w-0 flex-col items-center justify-end gap-1.5" title={`${dayLabel(d.date)} ${d.date}: ${formatValue(d.value)}`}>
              <span className={cn("max-w-full truncate text-[11px] tabular-nums", d.value > 0 ? "text-fg" : "text-transparent select-none")} aria-hidden>
                {d.value > 0 ? formatBar(d.value) : "0"}
              </span>
              <div className="flex w-full flex-1 items-end">
                <div
                  className={cn("w-full rounded-t-md transition-[height] duration-500 motion-reduce:transition-none", d.value > 0 ? (isToday ? "bg-brand" : "bg-brand/55") : "bg-hover")}
                  style={{ height: d.value > 0 ? `${height}%` : "3px" }}
                />
              </div>
              <span className={cn("text-[11px]", isToday ? "font-semibold text-fg" : "text-fg-2")} aria-hidden>{dayLabel(d.date)}</span>
            </div>
          );
        })}
      </div>
      {empty && <p className="mt-3 text-xs text-fg-2">{emptyMessage}</p>}
    </div>
  );
}
