"use client";

import { useState } from "react";
import { CheckCircle2Icon } from "lucide-react";
import { groupCurriculum } from "@/features/curriculum/curriculum-phases";
import { PHASE_COLORS } from "@/components/roadmap/roadmap-phase";
import {
  completedTopicsByDay,
  estimatedMinutesByDay,
  lastDays,
  loggedMinutesByDay,
  valuesForDays,
  weekSummary,
  type DailySeries,
} from "@/features/progress/progress-utils";
import { useToday } from "@/hooks/use-today";
import { formatDuration } from "@/lib/dates";
import { cn } from "@/lib/utils";
import { useStudyStore } from "@/stores/study-store";
import { DailyBarChart } from "./daily-bar-chart";
import { GradientProgress } from "./gradient-progress";

type TimeMode = "logged" | "estimated";

function Stat({ label, value, hint }: { label: string; value: string; hint?: string }) {
  return (
    <div className="rounded-lg border border-hairline bg-hover/40 p-3">
      <p className="text-xs text-fg-2">{label}</p>
      <p className="mt-1 text-lg font-semibold text-fg tabular-nums">{value}</p>
      {hint && <p className="mt-0.5 text-[11px] text-fg-2">{hint}</p>}
    </div>
  );
}

/** 7-day chart plus Monday-to-Sunday weekly summary for one daily series. */
function SeriesCard({ title, description, series, today, unit, formatTotal, formatBar, emptyMessage, controls }: {
  title: string; description: string; series: DailySeries; today: string; unit: string;
  formatTotal: (n: number) => string; formatBar: (n: number) => string; emptyMessage: string; controls?: React.ReactNode;
}) {
  const data = valuesForDays(series, lastDays(today, 7));
  const week = weekSummary(series, today);
  return (
    <div className="mt-4 rounded-lg border border-hairline glass p-5">
      <div className="flex flex-wrap items-start justify-between gap-3">
        <div className="min-w-0">
          <p className="text-sm font-medium text-fg">{title}</p>
          <p className="mt-1 text-xs text-fg-2">{description}</p>
        </div>
        {controls}
      </div>
      <DailyBarChart className="mt-4" data={data} today={today} formatValue={(n) => `${formatTotal(n)}`} formatBar={formatBar} emptyMessage={emptyMessage} />
      <div className="mt-4 grid gap-2 sm:grid-cols-3">
        <Stat label="Minggu ini" value={formatTotal(week.thisWeek)} hint="Senin sampai hari ini" />
        <Stat label="Minggu lalu" value={formatTotal(week.lastWeek)} hint="Senin sampai Minggu" />
        <Stat label="7 hari terakhir" value={formatTotal(week.last7Days)} hint={`${week.activeDays} dari 7 hari ${unit}`} />
      </div>
    </div>
  );
}

export function ProgressView() {
  const tasks = useStudyStore((state) => state.tasks);
  const reflections = useStudyStore((state) => state.reflections);
  const sessions = useStudyStore((state) => state.sessions);
  const today = useToday();
  const [timeMode, setTimeMode] = useState<TimeMode>("logged");
  const completed = tasks.filter((task) => task.status === "completed").length;
  const percent = tasks.length ? Math.round((completed / tasks.length) * 100) : 0;
  const mastery = {
    understood: tasks.filter((task) => task.mastery === "understood").length,
    partial: tasks.filter((task) => task.mastery === "partial").length,
    review: tasks.filter((task) => task.mastery === "review").length,
  };

  return (
    <main className="page-enter min-h-0 flex-1 overflow-y-auto p-4 sm:p-6">
      <div className="mx-auto max-w-3xl">
        <h1 className="text-xl font-semibold text-fg">Progress</h1>
        <p className="mt-1 text-sm text-fg-2">
          Fundamental Learning completion and self-assessment.
        </p>
        <div className="mt-6 rounded-lg border border-hairline glass p-5">
          <div className="flex items-end justify-between">
            <div>
              <p className="text-sm text-fg-2">Completed</p>
              <p className="mt-1 text-3xl font-semibold text-fg">{percent}%</p>
            </div>
            <p className="text-sm text-fg-2">
              {completed} / {tasks.length}
            </p>
          </div>
          <GradientProgress value={percent} label="Progres keseluruhan" className="mt-4" />
        </div>
        <div className="mt-4 rounded-lg border border-hairline glass p-5">
          <p className="text-sm font-medium text-fg">Per fase</p>
          <ul className="mt-3 space-y-4">
            {groupCurriculum(tasks).phases.map((phase) => {
              const colors = PHASE_COLORS[phase.def.accent];
              return (
                <li key={phase.def.id}>
                  <div className="flex items-baseline justify-between gap-3 text-sm">
                    <span className="text-fg">
                      Phase {String(phase.def.number).padStart(2, "0")} — {phase.def.title}
                    </span>
                    <span className="shrink-0 text-xs text-fg-2 tabular-nums">
                      {phase.completed} / {phase.total} · {phase.percent}%
                    </span>
                  </div>
                  <GradientProgress
                    value={phase.percent}
                    label={`Progres ${phase.def.title}`}
                    from={colors.from}
                    mid={colors.solid}
                    to={colors.solid}
                    className="mt-2 h-1.5"
                  />
                </li>
              );
            })}
          </ul>
        </div>
        <SeriesCard
          title="Waktu belajar"
          description={timeMode === "logged"
            ? "Durasi yang kamu catat lewat “Catat waktu belajar”."
            : "Estimasi: menit materi pada hari diselesaikan, bukan durasi yang diukur."}
          series={timeMode === "logged" ? loggedMinutesByDay(sessions) : estimatedMinutesByDay(tasks)}
          today={today}
          unit="belajar"
          formatTotal={formatDuration}
          formatBar={formatDuration}
          emptyMessage={timeMode === "logged"
            ? "Belum ada waktu belajar tercatat dalam 7 hari terakhir. Catat dari Agenda."
            : "Belum ada materi selesai dalam 7 hari terakhir."}
          controls={
            <div role="group" aria-label="Sumber data waktu belajar" className="flex rounded-lg border border-hairline p-0.5 text-xs">
              {([["logged", "Tercatat"], ["estimated", "Estimasi materi"]] as const).map(([value, label]) => (
                <button
                  key={value}
                  type="button"
                  aria-pressed={timeMode === value}
                  onClick={() => setTimeMode(value)}
                  className={cn("rounded-md px-2.5 py-1 transition-colors", timeMode === value ? "bg-selected text-fg" : "text-fg-2 hover:text-fg")}
                >
                  {label}
                </button>
              ))}
            </div>
          }
        />
        <SeriesCard
          title="Materi selesai"
          description="Jumlah materi yang diselesaikan per hari (sesuai tanggal belajar saat check-in)."
          series={completedTopicsByDay(tasks)}
          today={today}
          unit="ada materi selesai"
          formatTotal={(n) => `${n} materi`}
          formatBar={(n) => String(n)}
          emptyMessage="Belum ada materi selesai dalam 7 hari terakhir."
        />
        <div className="mt-4 grid gap-2 sm:grid-cols-3">
          {[
            ["Understand the material", mastery.understood],
            ["Understand some parts", mastery.partial],
            ["Need review", mastery.review],
          ].map(([label, count]) => (
            <div
              key={String(label)}
              className="rounded-lg border border-hairline glass p-4"
            >
              <p className="flex items-center gap-2 text-sm text-fg">
                <CheckCircle2Icon className="size-4 text-success" />
                {label}
              </p>
              <p className="mt-2 text-2xl font-semibold text-fg">{count}</p>
            </div>
          ))}
        </div>
        <div className="mt-4 rounded-lg border border-hairline glass p-5">
          <p className="text-sm font-medium text-fg">Study reflections</p>
          <p className="mt-1 text-sm text-fg-2">
            {reflections.length
              ? `${reflections.length} reflection${
                  reflections.length === 1 ? "" : "s"
                } saved locally`
              : "No reflections submitted yet."}
          </p>
        </div>
      </div>
    </main>
  );
}
