export type Understanding = "understood" | "partial" | "review";

export type StudyReflection = {
  id: string;
  taskId: string;
  submittedAt: string;
  text: string;
  understanding: Understanding;
};

export type PersonalAvailability = {
  startMinutes: number;
  flexible: boolean;
};

export type StudyTaskStatus = "pending" | "completed";

export type StudyTask = {
  id: string;
  order: number;
  title: string;
  description?: string;
  subtest: string;
  /** Independent subtest queues this topic belongs to (shared topics list several). */
  subtestIds?: string[];
  estimatedMinutes: number;
  /**
   * The day this topic is scheduled for. Only a topic that is open (unlocked) or finished has one: a
   * locked topic is not scheduled yet, so it has none. Derived from the queue + completion history by
   * `scheduleTasks`; it does not move just because time passes (that is what "overdue" measures).
   */
  originalDate?: string;
  status: StudyTaskStatus;
  /** The day the student studied it (chosen at check-in, editable later); noon Asia/Jakarta of that day. */
  completedAt?: string;
  /** The real moment the check-in was recorded; stays put when the completion day is edited. */
  recordedAt?: string;
  locked: boolean;
  mastery?: Understanding;
};

export type StudySession = {
  id: string;
  date: string;
  start: string;
  end: string;
  minutes: number;
  subtestId?: string;
  notes?: string;
};
