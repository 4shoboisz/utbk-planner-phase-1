import { addDays, diffDays, fromKey } from "@/lib/dates";
import { completionDateKey } from "@/lib/study-dates";
import type { CalEvent } from "@/lib/types";
import type { StudyTask } from "../curriculum/curriculum-types";
import { subtestIdsFromLabel } from "./subtest-queues";

export function getFirstIncomplete(tasks: StudyTask[]): StudyTask | undefined {
  return [...tasks].sort((a, b) => a.order - b.order).find((task) => task.status !== "completed");
}

/**
 * A topic is overdue only when it is open (not locked), scheduled, unfinished, and today is strictly AFTER
 * its scheduled day. Due today = not late. Locked and completed topics are never overdue.
 */
export function getOverdueTasks(tasks: StudyTask[], today: string): StudyTask[] {
  return withLockedState(tasks).filter((task) => getOverdueCount(task, today) > 0);
}

export function getNextUnlockedTask(tasks: StudyTask[]): StudyTask | undefined {
  return getFirstIncomplete(withLockedState(tasks));
}

/** Queues a task belongs to; falls back to its subtest label so older saved data still works. */
export function queueIdsOf(task: StudyTask): string[] {
  const ids = task.subtestIds?.length ? task.subtestIds : subtestIdsFromLabel(task.subtest);
  return ids.length ? ids : ["default"];
}

/**
 * Each subtest queue is sequential on its own: a task is locked only while an earlier task
 * in one of ITS queues is unfinished. Other queues are never blocked, and nothing is skipped.
 */
export function withLockedState(tasks: StudyTask[]): StudyTask[] {
  const blocked = new Set<string>();
  return [...tasks].sort((a, b) => a.order - b.order).map((task) => {
    const queues = queueIdsOf(task);
    const locked = queues.some((queue) => blocked.has(queue));
    if (task.status !== "completed") queues.forEach((queue) => blocked.add(queue));
    return { ...task, locked };
  });
}

/** Every pending task the student may start now (at most one open task per queue sequence). */
export function getAvailableTasks(tasks: StudyTask[]): StudyTask[] {
  return withLockedState(tasks).filter((task) => task.status === "pending" && !task.locked);
}

/** Whole days past the scheduled day; 0 when due today, not yet due, locked, unscheduled or completed. */
export function getOverdueCount(task: StudyTask, today: string): number {
  if (task.status === "completed" || task.locked || !task.originalDate) return 0;
  return Math.max(0, diffDays(task.originalDate, today));
}

export const DEFAULT_AVAILABILITY: Record<number, { start: number; targetMinutes: number }> = {
  1: { start: 1110, targetMinutes: 150 }, 2: { start: 1020, targetMinutes: 150 },
  3: { start: 1110, targetMinutes: 150 }, 4: { start: 1020, targetMinutes: 150 },
  5: { start: 1110, targetMinutes: 150 }, 6: { start: 540, targetMinutes: 150 },
  0: { start: 540, targetMinutes: 150 },
};

export function isDateUnavailable(date: string, fixedEvents: CalEvent[], blockedDates: string[] = []): boolean {
  return blockedDates.includes(date) || fixedEvents.some((event) => event.date === date && event.allDay);
}

export function hasEventConflict(events: CalEvent[], date: string, start: number, end: number): boolean {
  return events.some((event) => event.date === date && !event.allDay && start < event.end && end > event.start);
}

export function getAvailableStart(date: string, events: CalEvent[]): number {
  const availability = DEFAULT_AVAILABILITY[fromKey(date).getDay()] ?? { start: 1020, targetMinutes: 150 };
  let start = availability.start;
  for (const event of events.filter((item) => item.date === date && !item.allDay).sort((a, b) => a.start - b.start)) {
    if (start < event.end && start + availability.targetMinutes > event.start) start = event.end;
  }
  return Math.min(start, 1440 - availability.targetMinutes);
}

// ---------------------------------------------------------------------------------------------
// Progressive scheduling
//
// A topic is scheduled only when it opens. The first topic of every queue opens on the start day;
// every later topic opens when its prerequisite (the nearest earlier topic in each of its queues) is
// completed, and is scheduled for the next study day AFTER that completion day. Blocked dates are
// skipped. Locked topics have no date. Completed topics keep theirs. The result depends only on the
// queue, the completion history, the start date and the blocked dates, never on what "today" is,
// so recomputing it is safe and cannot drift or create duplicates.
// ---------------------------------------------------------------------------------------------

export type ScheduleOptions = { startDate: string; blockedDates: string[] };

const MAX_SKIPPED_DAYS = 400;

/** `from`, or the first following day that is not blocked. */
export function firstStudyDay(from: string, blockedDates: string[]): string {
  let day = from;
  for (let guard = 0; blockedDates.includes(day) && guard < MAX_SKIPPED_DAYS; guard++) day = addDays(day, 1);
  return day;
}

/** The next study day strictly after `after`. */
export function nextStudyDay(after: string, blockedDates: string[]): string {
  return firstStudyDay(addDays(after, 1), blockedDates);
}

const byOrder = (a: StudyTask, b: StudyTask) => a.order - b.order;

/** Nearest earlier task in each of the task's queues: what must be finished before it opens. */
export function prerequisitesOf(task: StudyTask, sorted: StudyTask[]): StudyTask[] {
  const at = sorted.findIndex((item) => item.id === task.id);
  const found = new Map<string, StudyTask>();
  for (const queue of queueIdsOf(task)) {
    for (let i = at - 1; i >= 0; i--) {
      if (queueIdsOf(sorted[i]).includes(queue)) { found.set(sorted[i].id, sorted[i]); break; }
    }
  }
  return [...found.values()];
}

/** Nearest later task in each of the task's queues: what opens after it. */
export function dependentsOf(task: StudyTask, sorted: StudyTask[]): StudyTask[] {
  const at = sorted.findIndex((item) => item.id === task.id);
  const found = new Map<string, StudyTask>();
  for (const queue of queueIdsOf(task)) {
    for (let i = at + 1; i < sorted.length; i++) {
      if (queueIdsOf(sorted[i]).includes(queue)) { found.set(sorted[i].id, sorted[i]); break; }
    }
  }
  return [...found.values()];
}

const completionDay = (task: StudyTask): string | undefined => (task.completedAt ? completionDateKey(task.completedAt) : undefined);
const latest = (days: string[]): string => days.reduce((a, b) => (a > b ? a : b));
const earliest = (days: string[]): string => days.reduce((a, b) => (a < b ? a : b));

/**
 * Assigns `originalDate` to every open topic and clears it on every locked one. Also refreshes `locked`.
 * Completed topics are returned untouched, so history is never rewritten.
 */
export function scheduleTasks(tasks: StudyTask[], { startDate, blockedDates }: ScheduleOptions): StudyTask[] {
  const sorted = withLockedState(tasks);
  const floor = firstStudyDay(startDate, blockedDates);
  return sorted.map((task) => {
    if (task.status === "completed") return task;
    if (task.locked) {
      const unscheduled: StudyTask = { ...task };
      delete unscheduled.originalDate;
      return unscheduled;
    }
    const finished = prerequisitesOf(task, sorted).flatMap((item) => completionDay(item) ?? []);
    const opens = finished.length ? nextStudyDay(latest(finished), blockedDates) : floor;
    return { ...task, originalDate: opens > floor ? opens : floor };
  });
}

// ---------------------------------------------------------------------------------------------
// Check-in date rules (the student may record a study day that is not today)
// ---------------------------------------------------------------------------------------------

export type CompletionBounds = { min?: string; max: string };

/**
 * Allowed completion days for a topic: not before its prerequisites were finished, not after a topic that
 * depends on it was already finished, and never in the future.
 */
export function completionBounds(tasks: StudyTask[], taskId: string, today: string): CompletionBounds | undefined {
  const sorted = [...tasks].sort(byOrder);
  const task = sorted.find((item) => item.id === taskId);
  if (!task) return undefined;
  const before = prerequisitesOf(task, sorted).flatMap((item) => completionDay(item) ?? []);
  const after = dependentsOf(task, sorted).flatMap((item) => (item.status === "completed" ? completionDay(item) ?? [] : []));
  const ceiling = after.length ? earliest(after) : undefined;
  return { min: before.length ? latest(before) : undefined, max: ceiling && ceiling < today ? ceiling : today };
}

/** Indonesian error message, or null when `date` is an allowed completion day for the topic. */
export function validateCompletionDate(tasks: StudyTask[], taskId: string, date: string, today: string): string | null {
  const bounds = completionBounds(tasks, taskId, today);
  if (!bounds) return "Materi tidak ditemukan.";
  if (!/^\d{4}-\d{2}-\d{2}$/.test(date)) return "Pilih tanggal yang valid.";
  if (date > today) return "Tanggal tidak boleh di masa depan.";
  if (bounds.min && date < bounds.min) return "Tidak boleh sebelum materi prasyaratnya selesai.";
  if (date > bounds.max) return "Tidak boleh setelah materi berikutnya yang sudah selesai.";
  return null;
}
