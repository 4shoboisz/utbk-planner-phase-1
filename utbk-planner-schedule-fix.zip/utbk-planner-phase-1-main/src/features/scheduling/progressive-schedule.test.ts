import { describe, expect, it } from "vitest";
import { FUNDAMENTAL_CURRICULUM } from "../curriculum/curriculum-data";
import type { StudyTask } from "../curriculum/curriculum-types";
import { completionTimestampFor } from "@/lib/study-dates";
import {
  completionBounds,
  getAvailableTasks,
  getOverdueCount,
  getOverdueTasks,
  nextStudyDay,
  scheduleTasks,
  validateCompletionDate,
  type ScheduleOptions,
} from "./scheduler";

const OPTIONS: ScheduleOptions = { startDate: "2026-11-09", blockedDates: ["2026-11-13", "2026-11-14", "2026-11-15"] };

const fresh = (options = OPTIONS): StudyTask[] =>
  scheduleTasks(FUNDAMENTAL_CURRICULUM.map((t) => ({ ...t, status: "pending" as const, locked: true })), options);

/** Completes a topic on a study day and re-schedules, exactly like the store does. */
const complete = (tasks: StudyTask[], id: string, day: string, options = OPTIONS): StudyTask[] =>
  scheduleTasks(tasks.map((t) => (t.id === id ? { ...t, status: "completed" as const, completedAt: completionTimestampFor(day) } : t)), options);

const dateOf = (tasks: StudyTask[], id: string) => tasks.find((t) => t.id === id)?.originalDate;

describe("progressive scheduling", () => {
  it("dates only the topics that are open on the start day; locked topics have no date", () => {
    const tasks = fresh();
    const open = tasks.filter((t) => !t.locked);
    expect(open.map((t) => t.id)).toEqual(["math-integer", "logic-cause-effect", "id-intro", "en-vocabulary"]);
    expect(open.every((t) => t.originalDate === "2026-11-09")).toBe(true);
    const locked = tasks.filter((t) => t.locked);
    expect(locked.length).toBe(FUNDAMENTAL_CURRICULUM.length - 4);
    expect(locked.every((t) => t.originalDate === undefined)).toBe(true);
    // "9 November for everything" is exactly the bug this guards against.
    expect(tasks.filter((t) => t.originalDate === "2026-11-09")).toHaveLength(4);
  });

  it("completing a topic opens the next one and dates it the day after the completion day", () => {
    const tasks = complete(fresh(), "math-integer", "2026-11-09");
    const next = tasks.find((t) => t.id === "math-fraction");
    expect(next?.locked).toBe(false);
    expect(next?.originalDate).toBe("2026-11-10");
    // the one after it is still locked and unscheduled
    expect(tasks.find((t) => t.order === (next?.order ?? 0) + 1)?.originalDate).toBeUndefined();
    // the finished topic keeps its date and its completion
    expect(dateOf(tasks, "math-integer")).toBe("2026-11-09");
    expect(tasks.find((t) => t.id === "math-integer")?.status).toBe("completed");
  });

  it("keeps moving forward as topics are finished in order", () => {
    let tasks = fresh();
    tasks = complete(tasks, "math-integer", "2026-11-09");
    tasks = complete(tasks, "math-fraction", "2026-11-10");
    const third = getAvailableTasks(tasks).find((t) => t.subtestIds?.includes("PK"));
    expect(third?.originalDate).toBe("2026-11-11");
  });

  it("skips blocked dates", () => {
    expect(nextStudyDay("2026-11-12", OPTIONS.blockedDates)).toBe("2026-11-16");
    const tasks = complete(fresh(), "math-integer", "2026-11-12");
    expect(dateOf(tasks, "math-fraction")).toBe("2026-11-16");
  });

  it("dates a topic from the day it was really studied, even when logged later", () => {
    // Studied on the 9th, remembered to log it on the 12th: the next topic follows the 9th, not the 12th.
    const tasks = complete(fresh(), "math-integer", "2026-11-09");
    expect(dateOf(tasks, "math-fraction")).toBe("2026-11-10");
    expect(getOverdueCount(tasks.find((t) => t.id === "math-fraction")!, "2026-11-12")).toBe(2);
  });

  it("opens a multi-queue topic only after every queue it belongs to is clear, then dates it once", () => {
    const tasks = complete(fresh(), "id-intro", "2026-11-09");
    const opened = getAvailableTasks(tasks).filter((t) => !["math-integer", "logic-cause-effect", "en-vocabulary"].includes(t.id));
    expect(opened).toHaveLength(1);
    expect(opened[0].originalDate).toBe("2026-11-10");
    expect(tasks).toHaveLength(FUNDAMENTAL_CURRICULUM.length); // no duplicates
  });

  it("re-dates pending topics when the start date moves, and never touches completed ones", () => {
    const done = complete(fresh(), "math-integer", "2026-11-09");
    const moved = scheduleTasks(done, { startDate: "2026-11-23", blockedDates: [] });
    expect(dateOf(moved, "math-integer")).toBe("2026-11-09");
    expect(dateOf(moved, "logic-cause-effect")).toBe("2026-11-23");
    expect(dateOf(moved, "math-fraction")).toBe("2026-11-23"); // never earlier than the new start
    expect(moved.filter((t) => t.status === "completed")).toHaveLength(1);
  });

  it("is idempotent: scheduling twice changes nothing", () => {
    const once = complete(fresh(), "math-integer", "2026-11-09");
    expect(scheduleTasks(once, OPTIONS)).toEqual(once);
  });
});

describe("overdue", () => {
  const tasks = complete(fresh(), "math-integer", "2026-11-09"); // math-fraction due 2026-11-10
  const due = tasks.find((t) => t.id === "math-fraction")!;

  it("is not overdue before or on the scheduled day", () => {
    expect(getOverdueCount(due, "2026-11-09")).toBe(0);
    expect(getOverdueCount(due, "2026-11-10")).toBe(0);
  });
  it("becomes overdue only after the scheduled day has passed", () => {
    expect(getOverdueCount(due, "2026-11-11")).toBe(1);
    expect(getOverdueCount(due, "2026-11-14")).toBe(4);
  });
  it("never counts locked or completed topics", () => {
    const locked = tasks.find((t) => t.locked)!;
    expect(getOverdueCount(locked, "2027-01-01")).toBe(0);
    expect(getOverdueCount(tasks.find((t) => t.id === "math-integer")!, "2027-01-01")).toBe(0);
    const overdueIds = getOverdueTasks(tasks, "2026-11-20").map((t) => t.id);
    expect(overdueIds.every((id) => !tasks.find((t) => t.id === id)!.locked)).toBe(true);
    expect(overdueIds).not.toContain("math-integer");
  });
});

describe("check-in date rules", () => {
  it("allows a past day, today, and rejects the future", () => {
    const tasks = fresh();
    expect(validateCompletionDate(tasks, "math-integer", "2026-11-09", "2026-11-12")).toBeNull();
    expect(validateCompletionDate(tasks, "math-integer", "2026-11-12", "2026-11-12")).toBeNull();
    expect(validateCompletionDate(tasks, "math-integer", "2026-11-13", "2026-11-12")).not.toBeNull();
    expect(validateCompletionDate(tasks, "math-integer", "bukan-tanggal", "2026-11-12")).not.toBeNull();
  });
  it("cannot be earlier than the prerequisite's completion day", () => {
    const tasks = complete(fresh(), "math-integer", "2026-11-10");
    expect(completionBounds(tasks, "math-fraction", "2026-11-12")).toEqual({ min: "2026-11-10", max: "2026-11-12" });
    expect(validateCompletionDate(tasks, "math-fraction", "2026-11-09", "2026-11-12")).not.toBeNull();
    expect(validateCompletionDate(tasks, "math-fraction", "2026-11-10", "2026-11-12")).toBeNull();
  });
  it("cannot move a finished topic past one that already depends on it", () => {
    let tasks = complete(fresh(), "math-integer", "2026-11-09");
    tasks = complete(tasks, "math-fraction", "2026-11-11");
    expect(completionBounds(tasks, "math-integer", "2026-11-20")).toEqual({ min: undefined, max: "2026-11-11" });
    expect(validateCompletionDate(tasks, "math-integer", "2026-11-12", "2026-11-20")).not.toBeNull();
    expect(validateCompletionDate(tasks, "math-integer", "2026-11-11", "2026-11-20")).toBeNull();
  });
});
