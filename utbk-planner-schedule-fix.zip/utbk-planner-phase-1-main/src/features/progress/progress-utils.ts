import type { StudySession, StudyTask } from "../curriculum/curriculum-types";
import { addDays, dayOfWeek, startOfWeek } from "@/lib/dates";
import { completionDateKey } from "@/lib/study-dates";
export function completionPercent(tasks: StudyTask[]): number { return tasks.length ? Math.round(tasks.filter((task) => task.status === "completed").length / tasks.length * 100) : 0; }

// ---------------------------------------------------------------------------------------------
// Daily / weekly statistics for the Progress charts. Everything is derived from saved data:
// `sessions` (study time the student logged) and `tasks` (the day each topic was completed).
// ---------------------------------------------------------------------------------------------

/** value per calendar day ("YYYY-MM-DD"); days without data are simply absent (= 0). */
export type DailySeries = Map<string, number>;
export type DayValue = { date: string; value: number };

/** Short Indonesian weekday labels, indexed like `dayOfWeek` (0 = Sunday). */
export const DAY_LABELS = ["Min", "Sen", "Sel", "Rab", "Kam", "Jum", "Sab"] as const;
export const dayLabel = (date: string): string => DAY_LABELS[dayOfWeek(date)];

const bump = (series: DailySeries, day: string, amount: number) => series.set(day, (series.get(day) ?? 0) + amount);

/** The `count` calendar days ending on `today`, oldest first. */
export function lastDays(today: string, count = 7): string[] {
  return Array.from({ length: count }, (_, i) => addDays(today, i - (count - 1)));
}

/** Study time the student logged ("Catat waktu belajar"): the measured duration of each session, per day. */
export function loggedMinutesByDay(sessions: StudySession[]): DailySeries {
  const series: DailySeries = new Map();
  for (const session of sessions) bump(series, session.date, session.minutes);
  return series;
}

/**
 * ESTIMATED completed study time: the `estimatedMinutes` of each topic on the day it was completed.
 * Topics do not store a measured duration, so this is an estimate, not what was actually studied.
 */
export function estimatedMinutesByDay(tasks: StudyTask[]): DailySeries {
  const series: DailySeries = new Map();
  for (const task of tasks) {
    if (task.status === "completed" && task.completedAt) bump(series, completionDateKey(task.completedAt), task.estimatedMinutes);
  }
  return series;
}

/** Number of topics completed per day (by the study day chosen at check-in). */
export function completedTopicsByDay(tasks: StudyTask[]): DailySeries {
  const series: DailySeries = new Map();
  for (const task of tasks) {
    if (task.status === "completed" && task.completedAt) bump(series, completionDateKey(task.completedAt), 1);
  }
  return series;
}

export const valuesForDays = (series: DailySeries, days: string[]): DayValue[] =>
  days.map((date) => ({ date, value: series.get(date) ?? 0 }));

const sumDays = (series: DailySeries, from: string, to: string): number => {
  let total = 0;
  for (let day = from; day <= to; day = addDays(day, 1)) total += series.get(day) ?? 0;
  return total;
};

export type WeekSummary = {
  /** Monday through `today` of the current week. */
  thisWeek: number;
  /** The whole previous Monday to Sunday week. */
  lastWeek: number;
  /** The 7 days ending today (what the chart shows). */
  last7Days: number;
  /** Days with any activity among those 7. */
  activeDays: number;
};

/** Weeks run Monday to Sunday. */
export function weekSummary(series: DailySeries, today: string): WeekSummary {
  const monday = startOfWeek(today, 1);
  const last7 = lastDays(today, 7);
  return {
    thisWeek: sumDays(series, monday, today),
    lastWeek: sumDays(series, addDays(monday, -7), addDays(monday, -1)),
    last7Days: sumDays(series, last7[0], today),
    activeDays: last7.filter((day) => (series.get(day) ?? 0) > 0).length,
  };
}
