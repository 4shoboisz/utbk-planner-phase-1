import { describe, expect, it } from "vitest";
import type { StudySession, StudyTask } from "../curriculum/curriculum-types";
import { completionTimestampFor } from "@/lib/study-dates";
import {
  completedTopicsByDay,
  estimatedMinutesByDay,
  lastDays,
  loggedMinutesByDay,
  valuesForDays,
  weekSummary,
} from "./progress-utils";

const session = (date: string, minutes: number): StudySession => ({ id: `${date}-${minutes}`, date, start: "17:00", end: "18:00", minutes });
const done = (id: string, day: string, estimatedMinutes: number): StudyTask => ({
  id, order: 1, title: id, subtest: "x", estimatedMinutes, status: "completed", locked: false, completedAt: completionTimestampFor(day),
});

describe("progress statistics", () => {
  it("lists the last 7 days ending today, oldest first", () => {
    expect(lastDays("2026-11-18")).toEqual(["2026-11-12", "2026-11-13", "2026-11-14", "2026-11-15", "2026-11-16", "2026-11-17", "2026-11-18"]);
  });

  it("is all zeros and safe with no data", () => {
    const days = lastDays("2026-11-18");
    expect(valuesForDays(loggedMinutesByDay([]), days).every((d) => d.value === 0)).toBe(true);
    expect(valuesForDays(completedTopicsByDay([]), days)).toHaveLength(7);
    expect(weekSummary(estimatedMinutesByDay([]), "2026-11-18")).toEqual({ thisWeek: 0, lastWeek: 0, last7Days: 0, activeDays: 0 });
  });

  it("sums logged session minutes per day (measured duration)", () => {
    const series = loggedMinutesByDay([session("2026-11-17", 60), session("2026-11-17", 45), session("2026-11-18", 30)]);
    expect(series.get("2026-11-17")).toBe(105);
    expect(valuesForDays(series, ["2026-11-16", "2026-11-17", "2026-11-18"]).map((d) => d.value)).toEqual([0, 105, 30]);
  });

  it("counts completed topics and their estimated minutes on the chosen study day", () => {
    const tasks = [done("a", "2026-11-17", 75), done("b", "2026-11-17", 75), done("c", "2026-11-16", 60), { ...done("d", "2026-11-16", 99), status: "pending" as const, completedAt: undefined }];
    expect(completedTopicsByDay(tasks).get("2026-11-17")).toBe(2);
    expect(completedTopicsByDay(tasks).get("2026-11-16")).toBe(1);
    expect(estimatedMinutesByDay(tasks).get("2026-11-17")).toBe(150);
    expect(estimatedMinutesByDay(tasks).get("2026-11-16")).toBe(60); // the pending one is ignored
  });

  it("splits weeks Monday to Sunday", () => {
    // 2026-11-18 is a Wednesday: this week = Mon 16 .. Wed 18; last week = Mon 9 .. Sun 15.
    const series = loggedMinutesByDay([session("2026-11-09", 10), session("2026-11-15", 20), session("2026-11-16", 30), session("2026-11-18", 40), session("2026-11-08", 99)]);
    const week = weekSummary(series, "2026-11-18");
    expect(week.thisWeek).toBe(70);
    expect(week.lastWeek).toBe(30); // Nov 8 (a Sunday of the week before) is excluded
    expect(week.last7Days).toBe(90); // Nov 12..18 = 20 + 30 + 40
    expect(week.activeDays).toBe(3);
  });
});
