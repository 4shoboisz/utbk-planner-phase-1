"use client";

import { create } from "zustand";
import { createJSONStorage, persist } from "zustand/middleware";
import { toast } from "sonner";
import { CURRICULUM_START_DATE, FUNDAMENTAL_CURRICULUM } from "@/features/curriculum/curriculum-data";
import type { PersonalAvailability, StudyReflection, StudySession, StudyTask, Understanding } from "@/features/curriculum/curriculum-types";
import { getFirstIncomplete, scheduleTasks, validateCompletionDate, type ScheduleOptions } from "@/features/scheduling/scheduler";
import { validateReflection } from "@/features/verification/reflection-validation";
import { formatLong, formatShort, toKey } from "@/lib/dates";
import { completionTimestampFor, isDayKey } from "@/lib/study-dates";
import { sessionMinutes } from "@/features/study/study-time";

const DEFAULT_AVAILABILITY: Record<number, PersonalAvailability> = {
  1: { startMinutes: 1110, flexible: false },
  2: { startMinutes: 1020, flexible: false },
  3: { startMinutes: 1110, flexible: false },
  4: { startMinutes: 1020, flexible: false },
  5: { startMinutes: 1110, flexible: false },
  6: { startMinutes: 1020, flexible: true },
  0: { startMinutes: 1020, flexible: true },
};

const DEFAULT_BLOCKED_DATES = ["2026-11-13", "2026-11-14", "2026-11-15"];
const DEFAULT_PLANNING_END = "2026-11-22";
const STATE_VERSION = 3;

type StudyState = {
  version: number;
  projectStartDate: string;
  targetMinutes: number;
  availability: Record<number, PersonalAvailability>;
  blockedDates: string[];
  planningEndDate: string;
  tasks: StudyTask[];
  reflections: StudyReflection[];
  sessions: StudySession[];
};

type StudyActions = {
  /**
   * Completes the open topic. `completedDate` is the day the student actually studied (YYYY-MM-DD);
   * it defaults to today and may be in the past (forgot to log it), never in the future. The real
   * time of this entry is stored separately as `recordedAt`.
   */
  completeTask: (taskId: string, text: string, understanding: Understanding, completedDate?: string) => boolean;
  /** Changes the study day of a topic that is already completed (same date rules as check-in). */
  setCompletionDate: (taskId: string, date: string) => boolean;
  logSession: (input: Omit<StudySession, "id" | "minutes">) => boolean;
  setProjectStartDate: (date: string) => void;
  setTargetMinutes: (minutes: number) => void;
  setAvailability: (day: number, availability: PersonalAvailability) => void;
  setBlockedDates: (dates: string[]) => void;
  setPlanningEndDate: (date: string) => void;
  exportData: () => string;
  importData: (json: string) => boolean;
  resetStudyData: () => void;
};

type PermanentTask = (typeof FUNDAMENTAL_CURRICULUM)[number];

/** A topic that is not finished: locked until the scheduler opens it, and unscheduled until then. */
const pendingTask = (permanent: PermanentTask): StudyTask => ({ ...permanent, status: "pending", locked: true });

const validIso = (value: unknown): value is string => typeof value === "string" && !Number.isNaN(Date.parse(value));

/**
 * Rebuilds one topic from the permanent curriculum plus saved progress. Only finished topics carry
 * history (completion day, record time, mastery). Everything else is re-derived, so a pending topic
 * can never keep a stale date from an older version of the app.
 */
function restoreTask(permanent: PermanentTask, saved?: Partial<StudyTask>): StudyTask {
  if (saved?.status !== "completed") return pendingTask(permanent);
  const completedAt = validIso(saved.completedAt) ? saved.completedAt : validIso(saved.recordedAt) ? saved.recordedAt : undefined;
  return {
    ...pendingTask(permanent),
    status: "completed",
    completedAt,
    // Entries saved before `recordedAt` existed were recorded when they were completed.
    recordedAt: validIso(saved.recordedAt) ? saved.recordedAt : completedAt,
    mastery: saved.mastery,
    originalDate: isDayKey(saved.originalDate) ? saved.originalDate : undefined,
  };
}

function restoreTasks(saved: StudyTask[] | undefined, options: ScheduleOptions): StudyTask[] {
  const byId = new Map((saved ?? []).map((task) => [task.id, task]));
  return scheduleTasks(FUNDAMENTAL_CURRICULUM.map((permanent) => restoreTask(permanent, byId.get(permanent.id))), options);
}

const scheduleOptionsOf = (state: Pick<StudyState, "projectStartDate" | "blockedDates">): ScheduleOptions => ({
  startDate: state.projectStartDate,
  blockedDates: state.blockedDates,
});

const initialTasks: StudyTask[] = scheduleTasks(FUNDAMENTAL_CURRICULUM.map(pendingTask), {
  startDate: CURRICULUM_START_DATE,
  blockedDates: DEFAULT_BLOCKED_DATES,
});

export const useStudyStore = create<StudyState & StudyActions>()(
  persist(
    (set, get) => ({
      version: STATE_VERSION,
      projectStartDate: CURRICULUM_START_DATE,
      targetMinutes: 150,
      availability: DEFAULT_AVAILABILITY,
      blockedDates: DEFAULT_BLOCKED_DATES,
      planningEndDate: DEFAULT_PLANNING_END,
      tasks: initialTasks,
      reflections: [],
      sessions: [],
      logSession: (input) => {
        const minutes = sessionMinutes(input.start, input.end);
        if (!input.date || minutes === null) { toast.error("Waktu tidak valid", { description: "Jam selesai harus setelah jam mulai." }); return false; }
        set((state) => ({ sessions: [...state.sessions, { ...input, id: crypto.randomUUID(), minutes }] }));
        toast.success("Waktu belajar tercatat", { description: `${minutes} menit` });
        return true;
      },
      completeTask: (taskId, text, understanding, completedDate) => {
        const error = validateReflection(text);
        if (error) { toast.error("Belum bisa diselesaikan", { description: error }); return false; }
        const state = get();
        const task = state.tasks.find((item) => item.id === taskId);
        if (!task || task.status === "completed" || task.locked) { toast.error("Materi belum dapat diselesaikan"); return false; }
        const today = toKey(new Date());
        const day = completedDate ?? today;
        const dateError = validateCompletionDate(state.tasks, taskId, day, today);
        if (dateError) { toast.error("Tanggal belum valid", { description: dateError }); return false; }
        const now = new Date().toISOString();
        const reflection: StudyReflection = { id: crypto.randomUUID(), taskId, submittedAt: now, text: text.trim(), understanding };
        // Completing a topic opens the next one in its queue(s), which the scheduler then dates.
        const tasks = scheduleTasks(
          state.tasks.map((item) => item.id === taskId
            ? { ...item, status: "completed" as const, completedAt: completionTimestampFor(day), recordedAt: now, mastery: understanding }
            : item),
          scheduleOptionsOf(state),
        );
        set((current) => ({ tasks, reflections: [...current.reflections, reflection] }));
        toast.success("Materi selesai", {
          description: day === today ? "Materi berikutnya sudah terbuka." : `Dicatat untuk ${formatShort(day)}. Materi berikutnya sudah terbuka.`,
        });
        return true;
      },
      setCompletionDate: (taskId, date) => {
        const state = get();
        const task = state.tasks.find((item) => item.id === taskId);
        if (!task || task.status !== "completed") { toast.error("Hanya materi yang sudah selesai yang bisa diubah tanggalnya"); return false; }
        const dateError = validateCompletionDate(state.tasks, taskId, date, toKey(new Date()));
        if (dateError) { toast.error("Tanggal belum valid", { description: dateError }); return false; }
        // recordedAt is left alone: it is the real time the entry was made.
        const tasks = scheduleTasks(
          state.tasks.map((item) => (item.id === taskId ? { ...item, completedAt: completionTimestampFor(date) } : item)),
          scheduleOptionsOf(state),
        );
        set({ tasks });
        toast.success("Tanggal selesai diperbarui", { description: formatLong(date) });
        return true;
      },
      // Pending topics are re-dated from the new start; completed history is never touched.
      setProjectStartDate: (date) => set((state) => ({
        projectStartDate: date,
        tasks: scheduleTasks(state.tasks, { startDate: date, blockedDates: state.blockedDates }),
      })),
      setTargetMinutes: (minutes) => set({ targetMinutes: Math.max(15, minutes) }),
      setAvailability: (day, availability) => set((state) => {
        const avl = { ...state.availability };
        avl[day] = availability;
        return { availability: avl };
      }),
      setBlockedDates: (dates) => set((state) => {
        const blockedDates = [...new Set(dates)].sort();
        return { blockedDates, tasks: scheduleTasks(state.tasks, { startDate: state.projectStartDate, blockedDates }) };
      }),
      setPlanningEndDate: (date) => set({ planningEndDate: date }),
      exportData: () => JSON.stringify({ version: STATE_VERSION, projectStartDate: get().projectStartDate, planningEndDate: get().planningEndDate, blockedDates: get().blockedDates, targetMinutes: get().targetMinutes, availability: get().availability, tasks: get().tasks, reflections: get().reflections, sessions: get().sessions }, null, 2),
      importData: (json) => {
        try {
          const data = JSON.parse(json);
          if (!Array.isArray(data.tasks) || !Array.isArray(data.reflections)) throw new Error("Invalid data");
          const ids = new Set(initialTasks.map((task) => task.id));
          if (data.tasks.length !== ids.size) throw new Error("Curriculum mismatch");
          const importedIds = data.tasks.map((task: StudyTask) => task.id);
          if (new Set(importedIds).size !== ids.size || !data.tasks.every((task: StudyTask) => ids.has(task.id))) throw new Error("Curriculum mismatch");
          if (!data.reflections.every((reflection: StudyReflection) => ids.has(reflection.taskId) && typeof reflection.text === "string" && typeof reflection.submittedAt === "string")) throw new Error("Invalid reflections");
          const projectStartDate = isDayKey(data.projectStartDate) ? data.projectStartDate : CURRICULUM_START_DATE;
          const blockedDates = Array.isArray(data.blockedDates) ? data.blockedDates.filter(isDayKey) : DEFAULT_BLOCKED_DATES;
          // Older backups dated every pending topic with the start day; restoring re-derives those dates.
          set({ projectStartDate, planningEndDate: data.planningEndDate ?? DEFAULT_PLANNING_END, blockedDates, targetMinutes: data.targetMinutes, availability: data.availability ?? DEFAULT_AVAILABILITY, tasks: restoreTasks(data.tasks, { startDate: projectStartDate, blockedDates }), reflections: data.reflections, sessions: Array.isArray(data.sessions) ? data.sessions : [] });
          toast.success("Data belajar berhasil dipulihkan");
          return true;
        } catch {
          toast.error("Import gagal", { description: "Format data tidak valid atau kurikulum tidak sesuai." });
          return false;
        }
      },
      resetStudyData: () => set({
        version: STATE_VERSION,
        projectStartDate: CURRICULUM_START_DATE,
        planningEndDate: DEFAULT_PLANNING_END,
        targetMinutes: 150,
        availability: DEFAULT_AVAILABILITY,
        blockedDates: DEFAULT_BLOCKED_DATES,
        tasks: initialTasks,
        reflections: [],
        sessions: [],
      }),
    }),
    {
      name: "utbk-study:state",
      version: STATE_VERSION,
      storage: createJSONStorage(() => localStorage),
      // On every load, re-read the permanent curriculum text (title, subtest, order, minutes) from code and
      // keep only the student's progress from storage. Pending topics are re-scheduled from that progress,
      // which also repairs saved data from versions that gave every topic the start date.
      merge: (persisted, current) => {
        const saved = (persisted ?? {}) as Partial<StudyState>;
        if (!Array.isArray(saved.tasks)) return { ...current, ...saved };
        const options = { startDate: saved.projectStartDate ?? CURRICULUM_START_DATE, blockedDates: saved.blockedDates ?? DEFAULT_BLOCKED_DATES };
        return { ...current, ...saved, tasks: restoreTasks(saved.tasks, options) };
      },
      migrate: (persisted) => {
        const data = persisted as Partial<StudyState>;
        const projectStartDate = data.projectStartDate ?? CURRICULUM_START_DATE;
        const blockedDates = data.blockedDates ?? DEFAULT_BLOCKED_DATES;
        return {
          ...data,
          version: STATE_VERSION,
          projectStartDate,
          targetMinutes: data.targetMinutes ?? 150,
          availability: data.availability ?? DEFAULT_AVAILABILITY,
          blockedDates,
          planningEndDate: data.planningEndDate ?? DEFAULT_PLANNING_END,
          tasks: restoreTasks(data.tasks, { startDate: projectStartDate, blockedDates }),
          reflections: data.reflections ?? [],
          sessions: data.sessions ?? [],
        } as StudyState;
      },
    },
  ),
);

export function getActiveStudyTask() { return getFirstIncomplete(useStudyStore.getState().tasks); }
