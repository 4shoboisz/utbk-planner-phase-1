import { beforeEach, describe, expect, it } from "vitest";
import { addDays, toKey } from "@/lib/dates";
import { completionDateKey } from "@/lib/study-dates";
import { useStudyStore } from "./study-store";

const reflection = "Hari ini saya mempelajari operasi bilangan bulat secara bertahap, memahami urutan pengerjaan, dan mencoba beberapa contoh soal dasar untuk menguji pemahaman saya sebelum melanjutkan materi berikutnya.";

describe("study persistence", () => {
  beforeEach(() => {
    useStudyStore.getState().resetStudyData();
  });

  it("preserves completion and reflection across export, reset, and restore", () => {
    const active = useStudyStore.getState().tasks.find((task) => !task.locked && task.status === "pending");
    expect(active).toBeDefined();
    expect(useStudyStore.getState().completeTask(active!.id, reflection, "partial")).toBe(true);

    const exported = useStudyStore.getState().exportData();
    useStudyStore.getState().resetStudyData();
    expect(useStudyStore.getState().reflections).toHaveLength(0);

    expect(useStudyStore.getState().importData(exported)).toBe(true);
    const restoredTask = useStudyStore.getState().tasks.find((task) => task.id === active!.id);
    expect(restoredTask?.status).toBe("completed");
    expect(restoredTask?.completedAt).toBeTruthy();
    expect(restoredTask?.mastery).toBe("partial");
    expect(useStudyStore.getState().reflections).toHaveLength(1);
    expect(useStudyStore.getState().reflections[0].taskId).toBe(active!.id);
  });

  it("rejects imports that omit or duplicate permanent curriculum tasks", () => {
    const data = JSON.parse(useStudyStore.getState().exportData());
    data.tasks = data.tasks.slice(1);
    expect(useStudyStore.getState().importData(JSON.stringify(data))).toBe(false);

    data.tasks = [...data.tasks, data.tasks[0]];
    expect(useStudyStore.getState().importData(JSON.stringify(data))).toBe(false);
  });
});

describe("scheduling and check-in dates", () => {
  const today = toKey(new Date());
  const store = () => useStudyStore.getState();
  const byId = (id: string) => store().tasks.find((task) => task.id === id);

  beforeEach(() => {
    store().resetStudyData();
    store().setBlockedDates([]);
    store().setProjectStartDate(addDays(today, -6));
  });

  it("starts with dates only on the open topics", () => {
    const dated = store().tasks.filter((task) => task.originalDate);
    expect(dated.every((task) => !task.locked)).toBe(true);
    expect(dated).toHaveLength(4);
    expect(store().tasks.filter((task) => task.locked).every((task) => task.originalDate === undefined)).toBe(true);
  });

  it("records the chosen study day and the real record time separately, and dates the next topic after it", () => {
    const studied = addDays(today, -3);
    const before = Date.now();
    expect(store().completeTask("math-integer", reflection, "understood", studied)).toBe(true);
    const done = byId("math-integer")!;
    expect(completionDateKey(done.completedAt!)).toBe(studied);
    expect(Date.parse(done.recordedAt!)).toBeGreaterThan(before - 1);
    expect(byId("math-fraction")?.locked).toBe(false);
    expect(byId("math-fraction")?.originalDate).toBe(addDays(studied, 1));
    expect(byId("math-integer")?.originalDate).toBe(addDays(today, -6)); // history untouched
  });

  it("defaults to today and rejects a future day or a day before the prerequisite", () => {
    expect(store().completeTask("math-integer", reflection, "understood", addDays(today, 1))).toBe(false);
    expect(byId("math-integer")?.status).toBe("pending");
    expect(store().completeTask("math-integer", reflection, "understood")).toBe(true);
    expect(completionDateKey(byId("math-integer")!.completedAt!)).toBe(today);
    expect(store().completeTask("math-fraction", reflection, "understood", addDays(today, -1))).toBe(false);
    expect(byId("math-fraction")?.status).toBe("pending");
  });

  it("edits the completion day later without touching the record time, and re-dates what follows", () => {
    expect(store().completeTask("math-integer", reflection, "understood", addDays(today, -4))).toBe(true);
    const recordedAt = byId("math-integer")!.recordedAt;
    expect(store().setCompletionDate("math-integer", addDays(today, -5))).toBe(true);
    expect(completionDateKey(byId("math-integer")!.completedAt!)).toBe(addDays(today, -5));
    expect(byId("math-integer")?.recordedAt).toBe(recordedAt);
    expect(byId("math-fraction")?.originalDate).toBe(addDays(today, -4));
    expect(store().setCompletionDate("math-integer", addDays(today, 2))).toBe(false); // future
    expect(store().setCompletionDate("logic-cause-effect", today)).toBe(false); // not completed yet
  });

  it("repairs a saved state that gave every topic the start date", () => {
    const legacy = JSON.parse(store().exportData());
    legacy.tasks = legacy.tasks.map((task: Record<string, unknown>) => ({ ...task, originalDate: legacy.projectStartDate, locked: false }));
    expect(store().importData(JSON.stringify(legacy))).toBe(true);
    expect(store().tasks.filter((task) => task.originalDate)).toHaveLength(4);
    expect(store().tasks.filter((task) => task.locked).every((task) => task.originalDate === undefined)).toBe(true);
  });

  it("survives a backup with an unreadable completion date", () => {
    expect(store().completeTask("math-integer", reflection, "understood", addDays(today, -2))).toBe(true);
    const broken = JSON.parse(store().exportData());
    broken.tasks = broken.tasks.map((task: Record<string, unknown>) => (task.id === "math-integer" ? { ...task, completedAt: "not a date", recordedAt: "also not" } : task));
    expect(store().importData(JSON.stringify(broken))).toBe(true);
    expect(byId("math-integer")?.status).toBe("completed");
  });
});
