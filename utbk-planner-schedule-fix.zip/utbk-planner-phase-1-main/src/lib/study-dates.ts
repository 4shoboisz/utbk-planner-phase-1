/**
 * Calendar-day helpers for study timestamps.
 *
 * A "study day" is an Asia/Jakarta calendar day, written "YYYY-MM-DD". Day keys are never produced with
 * `new Date("YYYY-MM-DD").toISOString()` (that parses as UTC and can shift the day); they come from
 * `Intl` with an explicit time zone, or from the local-date helpers in `lib/dates.ts`.
 */
const STUDY_TIME_ZONE = "Asia/Jakarta";

const DAY_FORMAT = new Intl.DateTimeFormat("en-CA", { timeZone: STUDY_TIME_ZONE, year: "numeric", month: "2-digit", day: "2-digit" });
const RECORDED_FORMAT = new Intl.DateTimeFormat("id-ID", { timeZone: STUDY_TIME_ZONE, day: "numeric", month: "short", hour: "2-digit", minute: "2-digit", hour12: false });

/** Calendar day (YYYY-MM-DD) of an ISO timestamp, in the study time zone. */
export function completionDateKey(iso: string): string {
  return DAY_FORMAT.format(new Date(iso));
}

/**
 * Timestamp stored as `completedAt` for a chosen completion day: noon in Asia/Jakarta (UTC+7, no DST).
 * Noon keeps the day stable under any display time zone; the real moment the entry was made is `recordedAt`.
 */
export function completionTimestampFor(dayKey: string): string {
  return new Date(`${dayKey}T12:00:00+07:00`).toISOString();
}

/** True for a real calendar day written as YYYY-MM-DD (rejects "2026-02-30" and similar). */
export function isDayKey(value: unknown): value is string {
  if (typeof value !== "string" || !/^\d{4}-\d{2}-\d{2}$/.test(value)) return false;
  const [y, m, d] = value.split("-").map(Number);
  const probe = new Date(Date.UTC(y, m - 1, d));
  return probe.getUTCFullYear() === y && probe.getUTCMonth() === m - 1 && probe.getUTCDate() === d;
}

/** "9 Nov 19.24" for the moment an entry was recorded. */
export function formatRecordedAt(iso: string): string {
  return RECORDED_FORMAT.format(new Date(iso)).replace(":", ".");
}
